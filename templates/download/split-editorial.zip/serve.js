// Local preview server for this EaseSourcing landing-page template.
// Run:  node serve.js   then open http://localhost:8765/
const http = require("http"), fs = require("fs"), path = require("path");
const ROOT = __dirname, PORT = 8765;
const TYPES = { ".html":"text/html", ".js":"text/javascript", ".json":"application/json", ".css":"text/css", ".svg":"image/svg+xml", ".png":"image/png", ".md":"text/plain" };
http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split("?")[0]);
  if (p === "/") p = "/split-editorial.html";
  const fp = path.join(ROOT, path.normalize(p));
  if (!fp.startsWith(ROOT)) { res.writeHead(403); return res.end("forbidden"); }
  fs.readFile(fp, (e, b) => {
    if (e) { res.writeHead(404); return res.end("not found"); }
    res.writeHead(200, { "Content-Type": TYPES[path.extname(fp)] || "application/octet-stream" });
    res.end(b);
  });
}).listen(PORT, () => console.log("Serving split-editorial.html on http://localhost:" + PORT + "/"));
